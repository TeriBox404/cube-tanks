// public/client.js
const socket = io();
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

let players = {};
let bullets = {};
let AmountOfPlayers = 0;
let c;



let lastShotTime = 0;
const shootCooldown = 5000; // milliseconds between shots


socket.on('currentPlayers', serverPlayers => {
  Object.assign(players, serverPlayers);
  draw();
});

socket.on('newPlayer', data => {
  players[data.id] = data;
  AmountOfPlayers++
});

socket.on('playerMoved', data => {
  if (players[data.id]) {
    players[data.id].x = data.x;
    players[data.id].y = data.y;
  }
});

socket.on('state', (serverPlayers, serverBullets) => {
  players = serverPlayers;
  bullets = serverBullets;
});

socket.on('playerDisconnected', id => {
  AmountOfPlayers--
  delete players[id];
});

socket.on('newBullet', data => {
  bullets[data.id] = data;
});

socket.on('playShotSound', data => {
      if(c.id != data){
      playSound("fire", 50)
    }
});

//socket.on('updateBullets', serverBullets => {
//  Object.assign(bullets, serverBullets);
//});

socket.on('playerHit', data => {

});


const keysDown = new Set();

document.addEventListener('keydown', e => {
  keysDown.add(e.key.toLowerCase());
});

document.addEventListener('keyup', e => {
  keysDown.delete(e.key.toLowerCase());
});

setInterval(() => {
  const now = Date.now();

  if (keysDown.has('w')) socket.emit('move', 'up');
  if (keysDown.has('s')) socket.emit('move', 'down');
  if (keysDown.has('a')) socket.emit('move', 'left');
  if (keysDown.has('d')) socket.emit('move', 'right');

  if (keysDown.has(' ') && now - lastShotTime >= shootCooldown) {
    socket.emit('shoot');
    playSound("reloading", 50)
    lastShotTime = now;
  }
}, 1000 / 60);






function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height); // clear the canvas

  // Draw bullets
  for (let id in bullets) {
    const b = bullets[id];
    ctx.fillStyle = 'black';
    ctx.fillRect(b.x, b.y, 5, 5);
  }

  // Draw rotated players
  for (let id in players) {
    const p = players[id];
    c = players[id]
    ctx.save();
    ctx.translate(p.x + 20, p.y + 10);   // move to center of player
    ctx.rotate(p.angle || 0);           // apply rotation
    if (isOdd(p.id)) {
      ctx.fillStyle = 'blue';
    } else {
      ctx.fillStyle = 'red';
    }

    ctx.fillRect(-20, -10, 40, 20);     // draw centered rectangle
    ctx.restore();
  }

  requestAnimationFrame(draw); // keep the loop going
}

function playSound(sound, volume = 100) {
  const audio = new Audio(sound + '.wav');
  audio.volume = volume / 100;
  audio.play();
}

function isOdd(num) {
  let one = num % 2
  if (one == 0) {
    return false
  } else {
    return true
  }
}