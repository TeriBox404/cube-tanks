// public/client.js
const socket = io();
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const players = {};
const bullets = {};

socket.on('currentPlayers', serverPlayers => {
  Object.assign(players, serverPlayers);
  draw();
});

socket.on('newPlayer', data => {
  players[data.id] = data;
});

socket.on('playerMoved', data => {
  if (players[data.id]) {
    players[data.id].x = data.x;
    players[data.id].y = data.y;
  }
});

socket.on('playerDisconnected', id => {
  delete players[id];
});

socket.on('newBullet', data => {
  bullets[data.id] = data;
});

socket.on('updateBullets', serverBullets => {
  Object.assign(bullets, serverBullets);
});

socket.on('playerHit', data => {

});



document.addEventListener('keydown', e => {
  const key = e.key.toLowerCase();
  if (key === 'a') socket.emit('move', 'left');
  if (key === 'd') socket.emit('move', 'right');
  if (key === 'w') socket.emit('move', 'up');
  if (key === 's') socket.emit('move', 'down');
  if (e.code === 'Space') {
  socket.emit('shoot');
}
});


function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height); // clear the canvas

  for (let id in players) {
    const p = players[id];
    ctx.fillStyle = 'blue';
    ctx.fillRect(p.x, p.y, 20, 20); // draw player
  }

  for (let id in bullets) {
    const b = bullets[id];
    ctx.fillStyle = 'black';
    ctx.fillRect(b.x, b.y, 5, 5); // draw bullet
  }

  requestAnimationFrame(draw); // keep the loop going
}


