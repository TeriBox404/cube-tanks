// server.js
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);

app.use(express.static('public'));

let players = {};
let bullets = {};
let bulletId = 0;


io.on('connection', socket => {
    console.log('A user connected:', socket.id);
    players[socket.id] = { x: 50, y: 50, color: getRandomColor() };

    // Send current state to new player
    socket.emit('currentPlayers', players);
    // Tell others a new player joined
    socket.broadcast.emit('newPlayer', { id: socket.id, ...players[socket.id] });

    socket.on('move', dir => {
        const player = players[socket.id];
        if (!player) return;
        if (dir === 'left') player.x -= 5;
        if (dir === 'right') player.x += 5;
        if (dir === 'up') player.y -= 5;
        if (dir === 'down') player.y += 5;
        io.emit('playerMoved', { id: socket.id, x: player.x, y: player.y });
    });


    socket.on('shoot', () => {
        const p = players[socket.id];
        if (!p) return;

        const id = bulletId++;
        bullets[id] = {
            id,
            x: p.x + 15,  // center of player
            y: p.y + 10,
            vx: 5,
            vy: 0,
        };

        io.emit('newBullet', bullets[id]);
    });



    socket.on('disconnect', () => {
        console.log('User disconnected:', socket.id);
        delete players[socket.id];
        io.emit('playerDisconnected', socket.id);
    });
});

function getRandomInt(min, max) {
    const minCeiled = Math.ceil(min);
    const maxFloored = Math.floor(max);
    return Math.floor(Math.random() * (maxFloored - minCeiled) + minCeiled);
}

function getRandomColor() {
    return '#' + Math.floor(Math.random() * 16777215).toString(16);
}

const port = getRandomInt(3000, 10000);

http.listen(port, () => {
    console.log('Server running on http://localhost:' + port);
});


setInterval(() => {
  const updatedBullets = {};

  for (let id in bullets) {
    const b = bullets[id];
    b.x += b.vx;
    b.y += b.vy;

    let hit = false;
    for (let pid in players) {
      if (pid === b.owner) continue;
      if (checkCollision(b, players[pid])) {
        io.emit('playerHit', { playerId: pid, bulletId: id });
        hit = true;
        break;
      }
    }

    // Only keep bullets that did NOT hit and are still on screen
    if (!hit && b.x >= 0 && b.x <= 500 && b.y >= 0 && b.y <= 500) {
      updatedBullets[id] = b;
    }
  }

  bullets = updatedBullets;
  io.emit('updateBullets', bullets);
  io.emit('state', players);
}, 1000 / 60);





function checkCollision(bullet, player) {
  // Check if bullet is within the bounds of the player
  return (
    bullet.x < player.x + 20 &&   // Right side
    bullet.x + 5 > player.x &&     // Left side
    bullet.y < player.y + 20 &&    // Bottom side
    bullet.y + 5 > player.y       // Top side
  );
}
