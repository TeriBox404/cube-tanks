// server.js
const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const os = require('os');
require('events').defaultMaxListeners = 30;


app.use(express.static('public'));

const localIP = getLocalIPAddress();
console.log(localIP)

let players = {};
let playerId = 0;
let bullets = {};
let bulletId = 0;


io.on('connection', socket => {
  console.log('A user connected:', socket.id);
  players[socket.id] = { x: 50, y: 50, angle: 0, id: playerId + 1};
  playerId++

  // Send current state to new player
  socket.emit('currentPlayers', players);
  // Tell others a new player joined
  socket.broadcast.emit('newPlayer', { id: socket.id, ...players[socket.id] });

  socket.on('move', dir => {
    const p = players[socket.id];
    if (!p) return;


    const speed = 1.5;
    const rotateSpeed = 0.03;

    if (dir === 'left') p.angle -= rotateSpeed;
    if (dir === 'right') p.angle += rotateSpeed;
    if (dir === 'up') {
      p.x += Math.cos(p.angle) * speed;
      p.y += Math.sin(p.angle) * speed;
    }
    if (dir === 'down') {
      p.x -= Math.cos(p.angle) * speed;
      p.y -= Math.sin(p.angle) * speed;
    }
  });





  socket.on('rotate', angleDelta => {
    if (players[socket.id]) {
      players[socket.id].angle += angleDelta;
    }
  });



  socket.on('shoot', () => {
    const p = players[socket.id];
    if (!p) return;

    const speed = 7;
    bullets[bulletId] = {
      id: bulletId,
      x: p.x + 10,
      y: p.y + 10,
      vx: Math.cos(p.angle) * speed,
      vy: Math.sin(p.angle) * speed,
      owner: socket.id
    };

    io.emit('newBullet', bullets[bulletId]);
    io.emit('playShotSound', p.id);
    bulletId++;
  });



  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
    delete players[socket.id];
    io.emit('playerDisconnected', socket.id);
  });
});


//function getRandomColor() {
//  return '#' + Math.floor(Math.random() * 16777215).toString(16);
//}

const port = 9026

http.listen(port, '0.0.0.0', () => {
  console.log(`Server running on http://${localIP}:${port}`);
});







setInterval(() => {
  const updatedBullets = {};

  for (let id in bullets) {
    const b = bullets[id];
    b.x += b.vx;
    b.y += b.vy;

    let hit = false;
    for (let pid in players) {
      if (pid === b.owner) continue;
      if (checkCollision(b, players[pid])) {
        io.emit('playerHit', { playerId: pid, bulletId: id });
        hit = true;
        break;
      }
    }

    // Only keep bullets that did NOT hit and are still on screen
    if (!hit && b.x >= 0 && b.x <= 500 && b.y >= 0 && b.y <= 500) {
      updatedBullets[id] = b;
    }
  }

  bullets = updatedBullets;
 // io.emit('updateBullets', bullets);
  io.emit('state', players, bullets);
}, 1000 / 60);





function checkCollision(bullet, player) {
  // Check if bullet is within the bounds of the player
  return (
    bullet.x < player.x + 20 &&   // Right side
    bullet.x + 5 > player.x &&     // Left side
    bullet.y < player.y + 20 &&    // Bottom side
    bullet.y + 5 > player.y       // Top side
  );
}

function getLocalIPAddress() {
  const interfaces = os.networkInterfaces();

  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return '127.0.0.1';
}